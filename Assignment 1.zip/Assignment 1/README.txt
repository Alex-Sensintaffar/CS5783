Imported Libraries:

numpy
matplotlib
math
pandas